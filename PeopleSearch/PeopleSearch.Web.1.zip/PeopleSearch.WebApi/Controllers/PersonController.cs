﻿using PeopleSearch.DataAccess;
using PeopleSearch.DataAccess.Entities;
using PeopleSearch.DataAccess.ORM;
using PeopleSearch.WebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PeopleSearch.WebApi.Controllers
{
    public class PersonController : ApiController
    {
        private readonly IPeopleSearchDAL _dal;

        public PersonController(IPeopleSearchDAL dal)
        {
            _dal = dal;
        }

        [HttpPost]
        [Route("api/person/search")]
        public IHttpActionResult Search(PersonSearchCriteriaDto criteria)
        {
            // Init criteria if not specified
            if (criteria == null) criteria = new PersonSearchCriteriaDto();
            else System.Threading.Thread.Sleep(2000);

            // Clean up criteria name
            criteria.Name = criteria?.Name?.Trim() ?? "";
            if (criteria.Name.Length == 0) criteria.Name = null;

            // Execute search
            var result = _dal.GetList<Person, PersonDto>(t =>
                    from p in t
                    where (criteria.Name == null || (p.FirstName.Contains(criteria.Name) || p.LastName.Contains(criteria.Name)))
                    select new PersonDto
                    {
                        PersonId = p.PersonId,
                        ImageUrl = p.ImageUrl,
                        FirstName = p.FirstName,
                        LastName = p.LastName,
                        AddressLine1 = p.AddressLine1,
                        City = p.City,
                        State = p.State,
                        ZipCode = p.ZipCode,
                        Interests = p.Interests.Select(j => j.Interest).ToList()
                    }
                );

            // Return results
            return Ok(result);
        }
    }
}
